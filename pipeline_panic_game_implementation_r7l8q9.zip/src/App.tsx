import { Authenticated, Unauthenticated, useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";

const STAGE_ICONS = ["🧑‍💻", "⚙️", "🧪", "🚀"];

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-xl font-semibold accent-text">Pipeline Panic</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-3xl mx-auto">
          <Content />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-8">
      <div className="text-center">
        <h1 className="text-5xl font-bold accent-text mb-4">Pipeline Panic</h1>
        <Authenticated>
          <GameContent />
        </Authenticated>
        <Unauthenticated>
          <p className="text-xl text-slate-600">Sign in to start playing</p>
          <SignInForm />
        </Unauthenticated>
      </div>
    </div>
  );
}

function GameContent() {
  const game = useQuery(api.games.getCurrentGame);
  const startNewGame = useMutation(api.games.startNewGame);
  const makeChoice = useMutation(api.games.makeChoice);
  const choices = useQuery(api.games.getChoices, game ? { stage: game.stage } : "skip");

  if (!game) {
    return (
      <button
        onClick={() => startNewGame()}
        className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
      >
        Start New Game
      </button>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex justify-between items-center">
        <div>Score: {game.score}</div>
        <div>Turns Left: {game.turnsLeft}</div>
        <div>Wrong Choices: {game.wrongChoices}/3</div>
      </div>

      <div className="flex justify-between items-center mb-8">
        {STAGE_ICONS.map((icon, i) => (
          <div
            key={i}
            className={`w-16 h-16 flex items-center justify-center text-2xl rounded-full ${
              i + 1 === game.stage
                ? "bg-indigo-100 border-2 border-indigo-500"
                : i + 1 < game.stage
                ? "bg-green-100"
                : "bg-gray-100"
            }`}
          >
            {icon}
          </div>
        ))}
      </div>

      {game.isGameOver ? (
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">
            {game.score >= 300 ? "Pipeline Success! 🎉" : "Pipeline Failed 💥"}
          </h2>
          <p className="mb-4">Final Score: {game.score}</p>
          <button
            onClick={() => startNewGame()}
            className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
          >
            Play Again
          </button>
        </div>
      ) : (
        <>
          <div className="text-xl mb-4">{game.currentProblem}</div>
          <div className="grid grid-cols-1 gap-4">
            {choices?.map((choice) => (
              <button
                key={choice}
                onClick={() => makeChoice({ gameId: game._id, choice })}
                className="px-4 py-2 bg-white border-2 border-indigo-200 rounded hover:bg-indigo-50"
              >
                {choice}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
