import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

const PROBLEMS = [
  {
    stage: 1,
    problem: "Code stage failing due to linting errors",
    correctAction: "Fix Lint Errors",
    choices: ["Fix Lint Errors", "Restart Build", "Skip Tests"],
  },
  {
    stage: 2,
    problem: "Build failing due to missing dependency",
    correctAction: "Update Dependencies",
    choices: ["Force Push", "Update Dependencies", "Clear Cache"],
  },
  {
    stage: 3,
    problem: "Tests failing in CI pipeline",
    correctAction: "Run Unit Tests",
    choices: ["Run Unit Tests", "Skip Stage", "Rebuild Container"],
  },
  {
    stage: 4,
    problem: "Deployment stuck in pending state",
    correctAction: "Restart Deploy Agent",
    choices: ["Force Deploy", "Restart Deploy Agent", "Roll Back"],
  },
];

export const getCurrentGame = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const games = await ctx.db
      .query("games")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(1);

    return games[0];
  },
});

export const startNewGame = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const problem = PROBLEMS[0];
    return await ctx.db.insert("games", {
      userId,
      stage: 1,
      score: 0,
      turnsLeft: 5,
      wrongChoices: 0,
      isGameOver: false,
      currentProblem: problem.problem,
      correctAction: problem.correctAction,
    });
  },
});

export const makeChoice = mutation({
  args: {
    gameId: v.id("games"),
    choice: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const game = await ctx.db.get(args.gameId);
    if (!game) throw new Error("Game not found");
    if (game.userId !== userId) throw new Error("Not your game");
    if (game.isGameOver) return game;

    let { score, wrongChoices, stage, turnsLeft } = game;
    const isCorrect = args.choice === game.correctAction;

    if (isCorrect) {
      score += 100;
      stage += 1;
    } else {
      score -= 50;
      wrongChoices += 1;
    }
    turnsLeft -= 1;

    const isGameOver = wrongChoices >= 3 || turnsLeft <= 0 || stage > PROBLEMS.length;
    const nextProblem = isGameOver ? null : PROBLEMS[stage - 1];

    return await ctx.db.patch(args.gameId, {
      score,
      wrongChoices,
      stage,
      turnsLeft,
      isGameOver,
      ...(nextProblem
        ? {
            currentProblem: nextProblem.problem,
            correctAction: nextProblem.correctAction,
          }
        : {}),
    });
  },
});

export const getChoices = query({
  args: { stage: v.number() },
  handler: async (ctx, args) => {
    return PROBLEMS[args.stage - 1]?.choices || [];
  },
});
