import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  games: defineTable({
    userId: v.id("users"),
    stage: v.number(),
    score: v.number(),
    turnsLeft: v.number(),
    wrongChoices: v.number(),
    isGameOver: v.boolean(),
    currentProblem: v.string(),
    correctAction: v.string(),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
